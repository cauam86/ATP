using System;

class Program {
  public static void Main (string[] args) {
    //irei usar a main para pedir o vetor, e um metodo para pegar o menor numero e sua posição.
    
    Console.WriteLine ("Digite 20 números");
    int[] vetor = new int[20];
    //For muito util para pedir os valores do vetor, já que a gente pode manipular a posição do vetor com o i.
    for(int i = 0; i < 20; i++){
      Console.WriteLine("Numero: ");
      vetor[i] = int.Parse(Console.ReadLine());
    }
    menorNumero(vetor);
  }

  static void menorNumero(int[] vetor){
    //bah declarando variavel util pra n dar merda la na frente
    int menor = vetor[0];
    int posicao = 0;
    //for para percorrer o vetor dnv e um if pra pegar o menor numero e sua posição.
    
    for (int i = 1; i<vetor.Length; i++){
      if (vetor[i] < menor){
        menor = vetor[i];
        posicao = i;
      }
    }
    //imprimindo dentro do metodo pq é mais facil mesmo kkkk
    Console.WriteLine("O menor numero é {0} e sua posição é {1}", menor, posicao);
  }
}