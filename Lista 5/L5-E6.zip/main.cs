using System;

namespace TemperaturasOutubro
{
    class Program
    {
        static void Main(string[] args)
        {
            // Declaração do vetor de temperaturas
            double[] temperaturas = new double[31];

            // Leitura das temperaturas
            for (int i = 0; i < temperaturas.Length; i++)
            {
                Console.WriteLine("Informe a temperatura do dia {0}: ", i + 1);
                temperaturas[i] = double.Parse(Console.ReadLine());
            }

            // Cálculo da menor e da maior temperatura
            double menorTemperatura = temperaturas[0];
            double maiorTemperatura = temperaturas[0];

            for (int i = 1; i < temperaturas.Length; i++)
            {
                if (temperaturas[i] < menorTemperatura)
                {
                    menorTemperatura = temperaturas[i];
                }

                if (temperaturas[i] > maiorTemperatura)
                {
                    maiorTemperatura = temperaturas[i];
                }
            }

            // Cálculo da temperatura média
            double temperaturaMedia = 0;

            for (int i = 0; i < temperaturas.Length; i++)
            {
                temperaturaMedia += temperaturas[i];
            }

            temperaturaMedia /= temperaturas.Length;

            // Contagem dos dias com temperatura inferior à média
            int diasTemperaturaInferiorMedia = 0;

            for (int i = 0; i < temperaturas.Length; i++)
            {
                if (temperaturas[i] < temperaturaMedia)
                {
                    diasTemperaturaInferiorMedia++;
                }
            }

            // Exibição dos resultados
            Console.WriteLine("Menor temperatura: {0}°C", menorTemperatura);
            Console.WriteLine("Maior temperatura: {0}°C", maiorTemperatura);
            Console.WriteLine("Temperatura média: {0}°C", temperaturaMedia);
            Console.WriteLine("Dias com temperatura inferior à média: {0}", diasTemperaturaInferiorMedia);
        }
    }
}
