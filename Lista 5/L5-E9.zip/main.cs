using System;

namespace Matrizes
{
    class Program
    {
        static void Main(string[] args)
        {
            // Declaração das matrizes
            int[,] matrizA = new int[4, 6];
            int[,] matrizB = new int[4, 6];

            // Preenchimento das matrizes
            PreencherMatriz(matrizA);
            PreencherMatriz(matrizB);

            // Soma das matrizes
            int[,] matrizS = SomarMatrizes(matrizA, matrizB);

            // Diferença das matrizes
            int[,] matrizD = DiferencaMatrizes(matrizA, matrizB);

            // Exibição das matrizes resultantes
            Console.WriteLine("Matriz S:");
            for (int i = 0; i < matrizS.GetLength(0); i++)
            {
                for (int j = 0; j < matrizS.GetLength(1); j++)
                {
                    Console.Write("{0} ", matrizS[i, j]);
                }
                Console.WriteLine();
            }

            Console.WriteLine();

            Console.WriteLine("Matriz D:");
            for (int i = 0; i < matrizD.GetLength(0); i++)
            {
                for (int j = 0; j < matrizD.GetLength(1); j++)
                {
                    Console.Write("{0} ", matrizD[i, j]);
                }
                Console.WriteLine();
            }
        }

        static void PreencherMatriz(int[,] matriz)
        {
            for (int i = 0; i < matriz.GetLength(0); i++)
            {
                for (int j = 0; j < matriz.GetLength(1); j++)
                {
                    Console.WriteLine("Informe o valor da posição ({0}, {1}): ", i, j);
                    matriz[i, j] = int.Parse(Console.ReadLine());
                }
            }
        }

        static int[,] SomarMatrizes(int[,] matrizA, int[,] matrizB)
        {
            int[,] matrizS = new int[matrizA.GetLength(0), matrizA.GetLength(1)];

            for (int i = 0; i < matrizA.GetLength(0); i++)
            {
                for (int j = 0; j < matrizA.GetLength(1); j++)
                {
                    matrizS[i, j] = matrizA[i, j] + matrizB[i, j];
                }
            }

            return matrizS;
        }

        static int[,] DiferencaMatrizes(int[,] matrizA, int[,] matrizB)
        {
            int[,] matrizD = new int[matrizA.GetLength(0), matrizA.GetLength(1)];

            for (int i = 0; i < matrizA.GetLength(0); i++)
            {
                for (int j = 0; j < matrizA.GetLength(1); j++)
                {
                    matrizD[i, j] = matrizA[i, j] - matrizB[i, j];
                }
            }

            return matrizD;
        }
    }
}
