using System;

namespace MediaTurma
{
    class Program
    {
        static void Main(string[] args)
        {
            // Declaração das variáveis pra n dar problema la na frente
            double[] notas = new double[10];
            double mediaTurma;
            int alunosAcimaMedia;

            // chama o bglh que nos fez
            PreencherNotas(notas);

            // chama o bglh2 que nois fez
            CalcularMediaEContarAcimaMedia(notas, out mediaTurma, out alunosAcimaMedia);

            // Exibição da média e do resultado da contagem
            Console.WriteLine("Média da turma: {0}", mediaTurma);
            Console.WriteLine("Número de alunos acima da média: {0}", alunosAcimaMedia);
        }

        static void PreencherNotas(double[] notas)
        {
          //for pra preencher as notas
            for (int i = 0; i < notas.Length; i++)
            {
                Console.WriteLine("Informe a nota do aluno {0}: ", i + 1);
                notas[i] = double.Parse(Console.ReadLine());
            }
        }

        static void CalcularMediaEContarAcimaMedia(double[] notas, out double mediaTurma, out int alunosAcimaMedia)
        {
          //declaração das variáveis pra n dar problema la na frente e calculando media no for e if
            mediaTurma = 0;
            alunosAcimaMedia = 0;

            for (int i = 0; i < notas.Length; i++)
            {
                mediaTurma += notas[i];

                if (notas[i] > mediaTurma)
                {
                    alunosAcimaMedia++;
                }
            }

            mediaTurma /= notas.Length;
        }
    }
}
