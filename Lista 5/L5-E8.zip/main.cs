using System;

namespace Matrizes
{
    class Program
    {
        static void Main(string[] args)
        {
            // Declaração da matriz
            int[,] matriz = new int[4, 4];

            // Preenchimento da matriz
            PreencherMatriz(matriz);

            // Soma dos elementos abaixo da diagonal principal
            int somaAbaixoDiagonalPrincipal = SomarAbaixoDiagonalPrincipal(matriz);

            // Elementos da diagonal principal
            Console.WriteLine("Elementos da diagonal principal:");
            for (int i = 0; i < matriz.GetLength(0); i++)
            {
                Console.WriteLine(matriz[i, i]);
            }

            // Soma dos elementos abaixo da diagonal principal
            Console.WriteLine("Soma dos elementos abaixo da diagonal principal: {0}", somaAbaixoDiagonalPrincipal);
        }

        static void PreencherMatriz(int[,] matriz)
        {
            for (int i = 0; i < matriz.GetLength(0); i++)
            {
                for (int j = 0; j < matriz.GetLength(1); j++)
                {
                    Console.WriteLine("Informe o valor da posição ({0}, {1}): ", i, j);
                    matriz[i, j] = int.Parse(Console.ReadLine());
                }
            }
        }

        static int SomarAbaixoDiagonalPrincipal(int[,] matriz)
        {
            int soma = 0;

            for (int i = 1; i < matriz.GetLength(0); i++)
            {
                for (int j = 0; j < i; j++)
                {
                    soma += matriz[i, j];
                }
            }

            return soma;
        }
    }
}
