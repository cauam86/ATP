using System;

namespace VetoresComValoresNegativos
{
    class Program
    {
        static void Main(string[] args)
        {
            // Declaração das variáveis
            int[] x = new int[10];
            int[] y;

            // Preenchimento do vetor x
            PreencherVetor(x);

            // Cópia dos valores negativos do vetor x para o vetor y
            y = CopiarValoresNegativos(x);

            // Exibição do conteúdo do vetor y
            ExibirVetor(y);
        }

        static void PreencherVetor(int[] vetor)
        {
            for (int i = 0; i < vetor.Length; i++)
            {
                Console.WriteLine("Informe o valor do elemento {0}: ", i + 1);
                vetor[i] = int.Parse(Console.ReadLine());
            }
        }

        static int[] CopiarValoresNegativos(int[] vetor)
        {
            int[] vetorNegativos = new int[vetor.Length];
            int indiceVetorNegativos = 0;

            for (int i = 0; i < vetor.Length; i++)
            {
                if (vetor[i] < 0)
                {
                    vetorNegativos[indiceVetorNegativos] = vetor[i];
                    indiceVetorNegativos++;
                }
            }

            return vetorNegativos;
        }

        static void ExibirVetor(int[] vetor)
        {
            Console.WriteLine("Valores do vetor:");

            for (int i = 0; i < vetor.Length; i++)
            {
                Console.WriteLine(vetor[i]);
            }
        }
    }
}
