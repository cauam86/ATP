using System;

class Program {
  public static void Main (string[] args) {
   
    //Declarei a variavel que vai receber o valor da formula da funcao
    
    double form;

    //pedir o valor de n, em seguida passar para formula e retornar o resultado na variavel que criei
    
    Console.WriteLine ("Informe um valor de n (inteiro e positivo)");

    int n = int.Parse(Console.ReadLine());

    form = formula(n);
    
    Console.WriteLine("O valor da formula é: " + form);
    
  }
 
  static double formula (double n){

    //variavel s serve de incubadora para formula kkkkk
    
    double s = 0;

    //repeticao para fazer a formula e retornar o resultado.
    
    for(int i = 1; i <= n; i++){
    s = Math.Pow(n, 2) / (n + 3);
  }
    return s;
  }
    
  }