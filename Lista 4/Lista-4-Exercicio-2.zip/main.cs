using System;

class Program {
  public static void Main (string[] args) {
    
    //criar o int pessoas para poder fazer a media la na frente
    
    int pessoas = 0;

    //criar a opcao para responder ou nao, no caso nao sabemos quantas repeticoes teremos, portanto precisamos deste metodo de s ou n, em seguida a verificacao da resposta e a repeticao para poder ir respondendo
    
    Console.WriteLine ("Responder pesquisa? (s/n)");
    char resposta = char.Parse(Console.ReadLine());

    do {
      if (resposta == 's'){
      pesquisa(pessoas);
        
      Console.WriteLine ("Responder pesquisa? (s/n)");
      resposta = char.Parse(Console.ReadLine());
      }
      
    } while (resposta == 's'); 

    //capricho de mensagem so
    
    Console.WriteLine("Encerrou a pesquisa");
  }

  static void pesquisa(int pessoas){
    
    //cada vez que o programa rodar aumenta o numero de pessoas
    
    pessoas = pessoas + 1;

    //obtendo as informacoes do usuario
    
    Console.WriteLine("Quantos filhos possui? ");
    int filhos = int.Parse(Console.ReadLine());

    Console.WriteLine("Quanto recebe de salário?");
    double salario = double.Parse(Console.ReadLine()); 

    //calculo da media das coisas e em seguida impressao das respostas

    double mediaSalario = salario/pessoas;
    int mediaFilhos = filhos/pessoas;

    Console.WriteLine("A média de salário até agora é de: " + mediaSalario);

    Console.WriteLine("A média de filhos até agora é de: " + mediaFilhos); 

  }
}

