using System;

class Program {
  public static void Main (string[] args) {

    //Podemos definir quantas repeticoes desde o inicio, portanto c sera nosso teto para o for
    
    Console.WriteLine ("Quantos conjuntos você vai digitar? ");
    int c = int.Parse(Console.ReadLine());

    //aqui no for conseguimos o valor de x y z para nosso processo organizar na ordem correta, e nosso for respeita o valor de c
    
    for (int i = 0; i <= c; i++){
      Console.WriteLine("Digite o conjunto de 3 numeros: ");
      int x = int.Parse(Console.ReadLine());
      int y = int.Parse(Console.ReadLine());
      int z = int.Parse(Console.ReadLine());

      ordem(x, y, z);
    }
    
  }
  
  static void ordem(int x, int y, int z){

    //sequencia de comandos para ter os numeros na ordem certa, e em seguida imprimimos eles na ordem correta.
    
    int maior = Math.Max(x, (Math.Max(y,z)));
    int menor = Math.Min(x, (Math.Min(y,z)));
    int meio = x + y + z - maior - menor;
    Console.WriteLine("A ordem: {0} {1} {2}", maior, meio, menor);
  }
}