using System;

class Program {
  public static void Main (string[] args) {
    Console.WriteLine ("Digite um sinal do teclado");
    char sinal = char.Parse(Console.ReadLine());

    switch (sinal){
      case '<':
        Console.WriteLine("SINAL DE MENOR");
        break;
      case '>':
        Console.WriteLine("SINAL DE MAIOR");
        break;
      case '=':
        Console.WriteLine("SINAL DE IGUAL");
        break;
    
      default: 
        Console.WriteLine("Outro sinal");
        break;
    }
  }
}