  using System;

  class Program {
      public static void Main (string[] args) {
          Console.WriteLine ("Digite o primeiro número:");
          double num1 = Convert.ToDouble(Console.ReadLine());
// Lê o primeiro número digitado pelo usuário e converte para double.
          Console.WriteLine ("Digite o segundo número:");
          double num2 = Convert.ToDouble(Console.ReadLine());
//Lê o segundo número digitado pelo usuário e converte para double.
          double maiorNumero = Math.Max(num1, num2);
          Console.WriteLine("O maior número é: " + maiorNumero);
// Calcula o maior número entre num1 e num2 e exibe o resultado.
      }
  }
