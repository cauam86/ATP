using System;

class Program {
  public static void Main (string[] args) {
    int num1, num2;
    
    Console.WriteLine ("Digite um numero inteiro");
    num1 = Convert.ToInt32(Console.ReadLine());

    Console.WriteLine ("Digite outro numero inteiro");
   num2 = Convert.ToInt32(Console.ReadLine());
    
    int resultado = num1 + num2;
    if (resultado >= 10)
    {
      resultado += 5;
    }
    else
    {
      resultado += 7;
    }
Console.WriteLine("Resultado final: " + resultado);
  }
}