using System;

class Program {
  public static void Main (string[] args) {
  double alturaRet, baseRet, perimetro, area, diagonal;
    
    Console.WriteLine ("Digite a base do triangulo");
    baseRet = double.Parse(Console.ReadLine());
    Console.WriteLine ("Digite a altura do triangulo");
    alturaRet = double.Parse(Console.ReadLine());

    perimetro = (alturaRet + baseRet) * 2;
    area = alturaRet * baseRet;
    diagonal = Math.Sqrt(Math.Pow(baseRet,2) + Math.Pow(alturaRet,2));

    Console.WriteLine ("perimetro: " + perimetro);
    Console.WriteLine ("area: " + area);
    Console.WriteLine ("diagonal: " + diagonal);
    
    }
}