using System;

class Program {
  public static void Main (string[] args) {
    
    int n =0;
    int fat =1;
    
    Console.WriteLine ("Digite um numero para ter seu fatorial calculado");
    n = int.Parse(Console.ReadLine());

    for (fat = 1; n >= 1; n = n - 1){
      fat = fat * n;
    }
    
    Console.WriteLine("O fatorial é: " + fat);
  }
}