using System;

class Program {
  public static void Main (string[] args) {
    //declarando as variaveis
   
    int positivos = 0;
    int negativos = 0;
    int zeros = 0;
    int numero;
    int quantidade;
    int a = 0;

    Console.WriteLine("Quantos numeros voce vai digitar?");
    quantidade = int.Parse(Console.ReadLine());

    for (a = 1; a <= quantidade; a++){
      Console.WriteLine("Digite um numero: ");
      numero = int.Parse(Console.ReadLine());
      if (numero>0){
        positivos++;
      }
      else if (numero<0){
        negativos++;
      }
      else {
        zeros ++;
      }

      }
    
    Console.WriteLine("Positivos: " + positivos);
    Console.WriteLine("Negativos: " + negativos);
    Console.WriteLine("Zeros: " + zeros);
  
    

   
    
  }
}