using System;

class Program {
  public static void Main (string[] args) {
    int positivos = 0;
    int negativos = 0;
    int zeros = 0;
    int total =0; 

    Console.WriteLine("Digite números inteiros");
    string [] numeros = Console.ReadLine().Split(' ');

    foreach (string numero in numeros){
      int valor = int.Parse(numero);
      if (valor>0){
        positivos++;
      }
      else if (valor<0){
        negativos++;
      }
      else{
        zeros++;
      }
      total++;
    }

    double porcentagemPositivos = (positivos/(double)total)*100;
    double porcentagemNegativos = (negativos/(double)total)*100;
    double porcentagemZeros = (zeros/(double)total)*100;

    Console.WriteLine("Positivos: " + positivos + " (" + porcentagemPositivos.ToString("F2") + "%)");

    Console.WriteLine ("Negativos: " + negativos + " (" + porcentagemNegativos.ToString("F2") + "%)");

    Console.WriteLine ("Zeros: " + zeros + " (" + porcentagemZeros.ToString("F2") + "%)");
  }
}