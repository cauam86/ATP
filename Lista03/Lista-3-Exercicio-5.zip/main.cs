using System;

class Program {
  public static void Main (string[] args) {

    int n = 0;
    double calc = 1;
    int fat = 1;
    int c = 0;
    
    do {
    Console.WriteLine("Digite um numero inteiro e positivo diferente de 0: ");
    n = int.Parse(Console.ReadLine());
    } while (n <= 0);
    
    for (int x = 1; x <=n; x++){

      for (c = x; c >= 1; c = c - 1){
        fat = fat * c;
      }
    
    calc = calc + 1;
    calc = calc / fat;
      }

    Console.WriteLine("O valor de E é: " + calc);
  }
}